(* ::Package:: *)

(* ::Input::Initialization:: *)
BeginPackage["cwsLieSymTools`"]
Unprotect@@Names["cwsLieSymTools`"];
ClearAll@@Names["cwsLieSymTools`"];

Print[" Loading the package cwsLieSymTools..."];
Print[" Author: Dr Celestin Wafo Soh (celestin dot wafo_soh at jsums dot edu)"];

symOperatorOnExpr::usage="symOperatorOnExpr[vars, symCoeffs]";
lieBracket::usage = "lieBracket[vars, symCoeffs1, symCoeffs2]";
operatorToListCoeff::usage="operatorToListCoeff[vars, op]";
lieBracketListForm::usage = " lieBracketListForm[vars, sym1, sym2]";
structureConstant::usage ="structureConstant[vars, listSym, paramList, dom]";
lieBracketForHuman::usage = "lieBracketForHuman[ vars, listSym, symb, paramList, dom]";
 commutatorTable::usage ="commutatorTable[vars, listSym, symb, paramList, dom]";
findAndSolve::usage ="findAndSolve[eqsList, varList, dom]";

Begin["`Private`"]

(* ------ Automatic Calculation of structure constants from Lie Symmetries------*)

(* Repesentation of a symmetry as an operator *)
symOperatorOnExpr[vars_, symCoeffs_]:=  symCoeffs.Table[D[#,vars[[i]]],{i,1,Length[vars]}]&;

(* Lie bracket of two symmetries. Each symmetry is represented by a list. *)
(* vars is the list of dependent and independent variables *)
(* The output is repesented as an operator *)
 
lieBracket[vars_, symCoeffs1_, symCoeffs2_]:=Module[{X1 = symOperatorOnExpr[vars, symCoeffs1], X2 = symOperatorOnExpr[vars, symCoeffs2]},
 (X1[X2[#]]-X2[X1[#]])&];

(* Conversion from the operator representation to the list representation *)

operatorToListCoeff[vars_,op_]:= Map[op,vars];

(* Computation of Lie bracket when the symmetries are given in list form *)
(* The output is also given in list form *)

lieBracketListForm[vars_, sym1_,sym2_]:=Map[Simplify, operatorToListCoeff[vars, lieBracket[vars, sym1,sym2]]];

(* Find linearly independent functions of vars in listSym *)
(* paramList is the list of parameters appearing in listSym *)

symParser[vars_, listSym_, paramList_:{}]:=Module[{expr1 = Map[ExpandAll,Join[listSym]],expr2},
expr2= Select[FixedPoint[Function[y, DeleteDuplicates[Flatten[Map[
If[(Head[#]===Times)||  (Head[#]===Plus) (*||(Head[x]=== Power)*) ||(Head[#]=== Minus),  List@@#,#]& ,y]]]],expr1],
  !NumericQ[#]&];
If[paramList=={}, expr2,
     Select[expr2, Function[x,Complement[Select[Flatten[{List@@(x)}], !NumericQ[#]& ],paramList]!={}]] ]
] 

(* Computation of the structure constants of a finite dimensional Lie algebra whose basis is listSym *)
(* vars is the list of dependent and independent variables *)
(* paramList is the list of parameters appearing in listSym *)

(* Solve one equation at the time by starting from the simplest one *)
myEliminate[eqList_, varList_,dom_:Complexes, sol_:{}]:=myEliminate[eqList, varList,dom, sol]=
Module[{temp1, temp2},
temp1=Sort[eqList,  (LeafCount[#1]<=LeafCount[#2])&]; (* Sort the list of equations *)
      If [temp1 =={},sol, temp2=Flatten[Solve[First[temp1],varList,dom]]; (* Solve the simplest equation and substitute it into the remaining equations *)  
temp1 = Select[Rest[temp1]/.temp2,  Not[# ===True]&]; (* Remove identities  after substitution into the remaining equations.*)
myEliminate[temp1,varList, dom,Join[sol,temp2]]] ];

findAndSolve[eqsList_,varList_,dom_:Complexes]:=findAndSolve[eqsList,varList,dom]=
Solve[myEliminate[eqsList,varList,dom]/.(a_->b_):>(a==b),varList];   (* Back-substitution  into the fully "eliminated" system *)

structureConstantHelper[vars_,listSym_, paramList_:{},dom_:Complexes][i_,j_]:=structureConstantHelper[vars,listSym, paramList,dom][i,j]=
Module[{ eqs, dim = Length[listSym], indepVars,dec, a,f, c},
 a = Array[f,dim];
eqs = ExpandAll[Sum[c[i,j,k]*listSym[[k]],{k,1,dim}]-lieBracketListForm[vars,listSym[[i]],listSym[[j]]]]; 
(* Expressing Lie brackets as linear combination of symmetries *)
indepVars = symParser[vars, listSym, paramList]; (* computing independent functions appearing in listSym *)
eqs = DeleteDuplicates[Flatten[Map[ (CoefficientRules[#, indepVars]/.{(a_ ->b_):>(b==0)})&, eqs]]]; (* Computing coefficients and setting them to zero *)
dec = Table[c[i,j,k],{k,1,dim}];
findAndSolve[eqs, dec,dom]/.{(c[i,j,z_]->t_):>( f[z]=t/.ConditionalExpression[a_,b_]:>a) }; (* definition of f *)
a
];
structureConstant[vars_,listSym_,paramList_:{},dom_:Complexes]:= structureConstant[vars,listSym,paramList,dom]=
structureConstantHelper[vars,listSym,paramList,dom][#1,#2][[#3]]&;

lieBracketForHuman[ vars_,listSym_,symb_, paramList_:{},dom_:Complexes]:= Module[{  f= structureConstantHelper[vars,listSym,paramList,dom][#1,#2]},
Sum[f[[k]]*Subscript[symb,k],{k,1,Length[listSym]}]]&;

(*commutatorTable[vars_, listSym_, symb_, paramList_:{}]:=Module[{dim = Length[listSym],t1,t2},
t1=Table[lieBracketForHuman[i,j, vars,listSym,symb, paramList],{i,1,dim},{j,1,dim}]; 
t1 = Map[Function[x, Prepend[x[[2]],Subscript[symb,x[[1]]]]], Transpose[{Range[dim],t1}]];
t2 =Prepend[Table[Subscript[symb,i],{i,1,dim}],"[,]\[UpperRightArrow]"]; 
Grid[Prepend[t1,t2],Frame\[Rule]All]];*)

commutatorTable[vars_,listSym_,symb_,paramList_:{},dom_:Complexes]:=commutatorTable[vars,listSym,symb,paramList,dom]=
Module[{dim =Length[listSym], a,m,f =lieBracketForHuman[ vars,listSym,symb, paramList,dom]},
m = Array[a, {dim+1,dim +1}]; (* array hosting the table *)
a[1,1] = "[,]\[UpperRightArrow]"; Table[a[1,i]=a[i,1]=Subscript[symb, i-1],{i,2,dim+1}]; 
Table[Table[a[i,j]=f[i-1,j-1],{i,2,j-1}],{j,2,dim+1}]; (* upper part of the table *)
Table[Table[a[j,i]= -a[i,j],{i,2,j-1}],{j,2,dim+1}]; (* exploiting commutator property to avoid recomputation *)
Table[a[i,i]=0,{i,2,dim+1}];
Grid[m, Frame->All]]; (*faster -- No recomputation!*)
End[]
 Protect@@Names["cwsLieSymTools`"]; 
EndPackage[]










