(* ::Package:: *)

(* ::Input::Initialization:: *)
BeginPackage["cwsAutoClassRev`"]
Unprotect@@Names["cwsAutoClassRev`"];
ClearAll@@Names["cwsAutoClassRev`"];

Print[" Loading the package cwsAutoClassRev..."];
Print[" Author: Dr Celestin Wafo Soh (celestin dot wafo_soh at jsums dot edu)"];

autoClassificationBruteForce::usage ="autoClassificationBruteForce[dim, c, dom, constraints][b, name]";
autoClassificationGen::usage = "autoClassificationGen[sigma, p, c, dim, popSize, numGen, dom, cond, constraints][b, name]";
allEquations::usage ="allEquations[dim, c, b]";
symbolicB::usage ="symbolicB[dim, b]";
simplifiedB::usage= " simplifiedB[dim, c , b, dom, constraints]";
allEquations::usage ="allEquations[dim, c, b]"; 
allStructMatrix::usage = "allStructMatrix[dim, c]";
Begin["`Private`"]

(* ------- Form  and solve the non-linear constraints ------------------------ *)
(*          The must important function is simplifiedB                              *) 

rhs[dim_, c_, b_]:=  (*Sum[c[#1,#2,k]*b[#3,k],{k,1,dim}]& ; *)   Sum[c[#1,#2,k]*b[k,#3],{k,1,dim}]&; 
lhs[dim_, c_, b_] := (*Sum[c[l,m,#3]*b[l,#1]*b[m,#2],{l,1,dim},{m,1,dim}]&; *) Sum[c[l,m,#3]*b[#1,l]*b[#2,m],{l,1,dim},{m,1,dim}]&;
equ[dim_, c_, b_]:= lhs[dim, c, b][#1,#2,#3] == rhs[dim, c, b][#1,#2,#3]& ;
equa[dim_, c_, b_ ]:= Flatten[Table[Table[equ[dim,c,b][i,j,#],{i,1,j-1}],{j,1,dim}]]&;
allEquations[dim_, c_, b_]:= allEquations[dim, c, b]=Flatten@Map[equa[dim,c,b],Range[dim]];             (*Flatten[Table[equa[dim,n,c,b],{n,1,dim}]];*)

(*contractedJac[dim_,c_,b_]:= Module[{ nu},
nu = Table[Sum[c[i,j,j],{j,1,dim}],{i,1,dim}];  (* contracted structure constants]*);
Table[0 == nu[[i]]-Sum[b[i,j]*nu[[j]],{j,1,dim}],{i,1,dim}]
];*)
 symbolicB[dim_, b_]:= Array[b,{dim,dim}]; (* Table[b[i,j],{i,1,dim},{j,1,dim}];*)


solveSys[dim_,c_,(*dom_:Complexes,*)constraints_:{}][b_]:= solveSys[dim,c,dom,constraints][b]=Module[{s= symbolicB[dim,b](*,jac*),sol}, 
(*$Assumptions=Fold[And, Map[Element[#, dom]&, Flatten[s]]]; *)
(*jac=contractedJac[dim,c,b];*) 
Solve[Join[(*jac*,*) constraints,Append[allEquations [dim,c,b], Det[s]!=0]],Flatten[s]]//Simplify(*//Normal*)
];

realQ[x_]:= FreeQ[ComplexExpand[x],I];
realMatrixQ[m_]:=Fold[And, Map[realQ,Flatten[m]]];
 
simplifiedB[dim_,c_,b_, dom_:Complexes,constraints_:{}]:=simplifiedB[dim,c,b, dom,constraints]= Module[{ sol = solveSys[dim,c,(*dom,*)constraints][b], 
bb = symbolicB[dim,b], bs}, bs=  Map[ bb/.#&,sol];
If[dom=== Reals, Select[bs, realMatrixQ], bs]
]//Simplify(*//Normal*);

(*splitEquations[dim_, c_, b_,lfcount_:30]:= Module[{f = Keys@*ToRules ,eqs= allEquations[dim,c,b], tally ={}, currentLin},
eqs = Select[eqs, Not[#===True]&];
currentLin = Select[eqs, f[#]== 0&];
While[currentLin !={},
tally = Join[tally, currentLin];
 eqs =Select[Complement[eqs, currentLin]/. Map[#/.(a1_==b1_):>(b1->a1)&,   tally], Not[# === True]&];
currentLin = Select[eqs, f[#]==0&]];
Join[tally, Select[eqs, LeafCount[#]<= lfcount&] ]
];
 simplifiedBhighDim[dim_,c_,b_, dom_:Complexes, constraints_:{},lfcount_:30]:= simplifiedBhighDim[dim,c,b, dom, constraints,lfcount]= Module[{mat = symbolicB[dim,b], vars,sol, allDet },
vars = Flatten[mat];
sol = Solve[splitEquations[dim,c,b,lfcount],vars,dom];
mat = Map[  mat/.#& , sol]//Simplify;
allDet = Map[Det, mat]; 
mat[[Map[#[[2]]&,Select[Transpose[{allDet, Range[Length[allDet]]}], Not[ #[[1]]===0]&]]]]
];
*)


(* ---------- Construct the structure matrices ------------------------------- *)

structMatrix[dim_,c_]:= (*Table[c[j,#,i],{i,1,dim},{j,1,dim}]&;*) Table[c[i,#,j],{i,1,dim},{j,1,dim}]&;  (* Compute one structure matrix *)
allStructMatrix[dim_, c_]:= allStructMatrix[dim,c]=Map[structMatrix[dim,c], Range[dim]]; (*Table[structMatrix[dim,m,c],{m,1,dim}]; *) (* compute all the structure matrices *)



(* -------- Application of the adjoint action to simplify the automorphisms resulting from solving the nonlinear constraints --------- *)
(*           The most important function is reduceB                                                                                       *) 

(*findEpsAndReduceB[k_,v_,dom_:Complexes][z_]:=Module[{s},
s=Flatten[Solve[SelectFirst[Flatten[z],Function[y,  Flatten[Solve[y \[Equal]v, k]] \[NotEqual]{} (*&&  Solve[y \[Equal]v, k]\[NotEqual]{{}}*)]]\[Equal] v,k]];
Print[s];
If[s \[Equal]{}, z , Map[(z/. #)&,s]]]; *)

cleanCalculations[x_]:=cleanCalculations[x]=Module[{  f= ((#===Indeterminate )||(#===Infinity)||(#===ComplexInfinity))&,s },
s =Flatten[x//Normal]; s=SelectFirst[s, f]; If [s==Missing["NotFound"], x, {}]];

findEpsAndReduceB[k_,v_,dom_:Complexes,constraints_:{}][z_]:= findEpsAndReduceB[k,v,dom,constraints][z]=  Module[{eq, f, s, res ,z1},
z1 =If[v==0, z, Diagonal[z]];
eq = Select[Flatten[z1], Not[NumericQ[#]] && Not[FreeQ[#, k]] &] ;
f= Function[x, Module[{temp = Flatten[Solve[Append[constraints, x ==v || x==-v],k ,dom]]}, (*(temp \[NotEqual] {{}})&&*)(temp !={})&&  Head[temp]=!= Solve ]];  
eq  = SelectFirst[eq,f]; 
 If[eq ===Missing["NotFound"], {z/.k->0},  s= DeleteDuplicates[Flatten[Solve[Append[ constraints ,eq == v|| eq==-v], k,dom]](*//Normal*)]; 
res= Select[Map[cleanCalculations, Map[(z/. #)&,s]], Not[#=={}]& ];  If[res=={},{z/.k->0}, res]]];


zeroMatrix[n_]:=zeroMatrix[n]= ConstantArray[0,{n,n}] ;(*Table[0,{i,1,n},{j,1,n}];*) (* Helper function for producing a zero matrix of order n *)
 diagonalQ [ m_]:=diagonalQ [ m]= m -DiagonalMatrix[Diagonal[m]]=== zeroMatrix[Length[m]]; (*  m - DiagonalMatrix@*Diagonal@m \[Equal] zeroMatrix@*Length@m *)

(* Split a list into two sublist according to whether the violate a criteria or satisfy it *)
filterList[list_, pred_]:= Module[{s =Select[list, pred]}, {s, Complement[list,s]}];

(*filterList[list_, pred_, acc1_:{}, acc2_:{}]:=   Which[ list\[Equal]{}, {acc1,acc2}, pred[list[[1]]],filterList[Rest[list],pred, Prepend[acc1, list[[1]]],acc2],
!pred[list[[1]]], filterList[Rest[list],pred , acc1 , Prepend[acc2, list[[1]]]]];*)

gatherByDiagonal[ mlist_]:= gatherByDiagonal[ mlist] =     filterList[mlist,diagonalQ];

myOuter[f_, lst_,a_]:=myOuter[f, lst,a]=  Map[ f[#,a]&,lst];

(*innerAutoQ[lst_, b_,dom_]:= Module[{sol, k},
If[lst=={}, False,
sol =Solve[{MatrixExp[k  lst[[1]]]==b, k!=0}, k];
If[ sol !={}, True, innerAutoQ[Rest@lst, b,dom]]]];*)

reduceB[c_,dim_, perm_,dom_:Complexes,constraints_:{}][b_]:=reduceB[c,dim, perm,dom,constraints][b]=Module[{f, g,  auto= Permute[allStructMatrix[dim, c],perm], k, sb={b}},
$Assumptions = Fold[And, Flatten[Table[Element[b[i,j], dom],{i,1,dim}, {j,1,dim}]]]&& Element[k,dom];
g[z_,x_]:= If[diagonalQ[MatrixExp[z*x]], findEpsAndReduceB[z,1,dom,constraints], findEpsAndReduceB[z,0,dom,constraints]];
f = Join@@Map[g[k,#2] , myOuter[Dot, #1, MatrixExp[k*#2]]]&; (* Simplification using  inner automorphisms *)
  {Fold[f, sb, auto] , perm }]//Simplify;         (* First use the non-diagonal automorphisms permuted according to perm *)


(*------- Applying a genetic strategy for finding an optimal representative of each equivalence class -------------*)


(* Choosing a random order for the reduction using non-diagonal canonical inner automorphisms *)

reduceBr[c_,dim_, dom_:Complexes,constraints_:{}][b_]:= Module[{  perm },
perm =   RandomSample[Range[dim]]; (* pick a random reduction order *)
reduceB[c,dim, perm,dom,constraints][b]]; (* reduce *)

autoReduceB[c_,dim_,dom_:Complexes,constraints_:{}][b_]:=Module[{trial},
trial = reduceBr[c,dim,dom,constraints][b];
(*trial = Select [trial[[1]],  (cleanCalculations[#] !={})&];*)
If[trial[[1]]=={}, autoReduceB[c,dim,dom,constraints][b],  trial (*{trial, perm}*)]]; (* Replaced trial with trial[[1]] *)

(*autoReduceBr[c_,dim_,n_:1, dom_:Complexes][b_]:=autoReduceBr[c,dim,n, dom][b]= DeleteDuplicates[Join@@Table[autoReduceB[c,dim,dom][b][[1]],{j,1,n}]];*)

(*autoClassificationMC[c_,dim_, n_, dom_:Complexes, cond_:False][b_]:= Module[{s}, s=Join@@Map[autoReduceBr[c,dim,n, dom],simplifiedB[dim,c,b]];
If[cond,s, DeleteDuplicates[s//Normal]]];*)

(* Fitness function *)

sparsityMatrix[mat_]:= Length@ Select[Flatten[mat], # ===0 &];
fitnessMatrixList[lstMat_]:= Module[{s = Normal/@lstMat},If[ s==={} ,0, GeometricMean@Map[sparsityMatrix, s]]];

(* Cross-over strategy *)

randomSwap[lst_]:= Module[{i,j, lst1=lst},
{i,j}= { RandomChoice[Range[Length[lst]]],RandomChoice[Range[Length[lst]]]}; {lst1[[i]],lst1[[j]]}={ lst1[[j]],lst1[[i]]}; lst1];
mateAndSelect[p_,par1_, par2_,c_, dim_,dom_:Complexes,constraints_:{}][b_]:=mateAndSelect[p,par1, par2,c, dim,dom,constraints][b]=
 Module[{s1, s2, perm1, perm2, child1, child2, child3, child4,child5, child6,child7, child8 ,  pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8},
s1 = par1[[1]]; perm1 = par1[[2]];
s2 = par2[[1]]; perm2 = par2[[2]];
pc1 = PermutationProduct[perm1,perm2]; pc2 =  PermutationProduct[perm2,perm1];
pc3 = PermutationProduct[perm1,perm1]; pc4 = PermutationProduct[perm2,perm2];
pc5 = InversePermutation[perm1]; pc6 = InversePermutation[perm2];
pc7 = PermutationProduct[pc5, perm2, pc5]; pc8 = PermutationProduct[pc6, perm1, pc6];
If[RandomReal[]<p, pc1 =randomSwap[pc1]; pc2 = randomSwap[pc2]; pc3= randomSwap[pc3];
 pc4 = randomSwap[pc4]; pc5 =randomSwap[pc5]; pc6 = randomSwap[pc6]; pc7 = randomSwap[pc7];pc8 = randomSwap[pc8] ,##&[]];
child1 = reduceB[c,dim,pc1,dom,constraints][b];   (* mutate child1 *)
child2 = reduceB[c,dim,pc2,dom,constraints][b];
child3 = reduceB[c,dim,pc3,dom,constraints][b];
 child4 = reduceB[c,dim,pc4,dom,constraints][b];
child5 = reduceB[c,dim,pc5,dom,constraints][b];
child6 = reduceB[c,dim,pc6,dom,constraints][b];
child7 = reduceB[c,dim,pc7,dom,constraints][b];
child8 = reduceB[c,dim,pc8,dom,constraints][b];
Sort[{par1,par2, child1,child2,child3,child4,child5, child6, child7, child8}, (fitnessMatrixList[#1]>= fitnessMatrixList[#2])&][[1]] (* select the fittess*)
];

renameVariable[name_, vars_,mat_, dom_:Complexes] := Module[{m = Select[DeleteDuplicates[Flatten[mat]], !NumericQ[#]&], eqs,rules},
eqs  = Map[#[[1]]== Subscript[name, #[[2]]]&,  Transpose[{m,Range[Length[m]]}]];
rules = Solve[Eliminate[eqs, vars], Table[Subscript[name,i],{i,1,Length[m]}],dom]//Simplify;
(*eqs = Map[eqs/.#&, rules];
rules = Join@@Map[Solve[#,vars, dom]&, eqs]//Simplify;
Map[ mat/.#&, rules] *)
Map[(mat/. (eqs/.((x_ == y_):>(x->y))))/.#&, rules]
(*{FixedPoint[Function[a, Map[(a/. (eqs/.((x_ == y_):>(x->y))))/.#&, rules][[1]]],mat]}*)
];
 
buildOneGeneration[sigma_,p_,c_,dim_, weight_, currentPop_,0, dom_:Complexes,  finalPop_:{},constraints_:{}][b_]:=
buildOneGeneration[sigma,p,c,dim, weight, currentPop,0, dom,  finalPop,constraints][b]= finalPop;
buildOneGeneration[sigma_,p_,c_, dim_,  weight_, currentPop_, count_, dom_:Complexes, finalPop_:{},constraints_:{}][b_]:=
buildOneGeneration[sigma,p,c, dim,  weight, currentPop, count, dom, finalPop,constraints][b]=Module[{par1, par2, selected,fitb, k , h, z},
fitb :=fitnessMatrixList[{b}];
$Assumptions = Element[z, dom];
k :=Length[gatherByDiagonal[MatrixExp[z*#]&/@allStructMatrix[dim, c] ][[2]]];
h := Length[Select[Flatten[b], !NumericQ[#]&]];
{par1,par2} = RandomSample[ weight ->currentPop, 2];
selected =mateAndSelect[p, par1, par2,c, dim,dom,constraints][b];
If[fitnessMatrixList[selected[[1]]]>=sigma*(Min[k,h] +fitb),
  {selected},buildOneGeneration[sigma,p, c,dim,weight, currentPop, count-1,dom , Append[finalPop,selected],constraints][b]]];

buildManyGenerations[sigma_,p_, c_,dim_,weight_, currentPop_,0, dom_:Complexes,constraints_:{}][b_]:= 
buildManyGenerations[sigma,p, c,dim,weight, currentPop,0, dom,constraints][b]=currentPop;
buildManyGenerations[sigma_,p_, c_,dim_,weight_, currentPop_, numGen_, dom_:Complexes ,constraints_:{}][b_]:=
buildManyGenerations[sigma,p, c,dim,weight, currentPop, numGen, dom,constraints ][b]=
Module[{cp = buildOneGeneration[sigma,p, c,dim,weight, currentPop,Length[currentPop],dom,constraints][b], w},
If [Length[cp] ==1, cp,
w=Map[fitnessMatrixList,Map[First,cp]];
buildManyGenerations[sigma,p, c,dim,w, cp,numGen-1, dom,constraints][b]]];

(* sigma: percentage of max fitness that is acceptable for early convergence *)
(*  A choice of close to igma = 0.5 seems good *)
(* p  is the mutation rate --- choose p very small e.g p = 0.0001. High mutation rate implies that children looses parents traits *)
(* Mutation is important for a better coverage of the search space. It prevents convergence to local optima *)
(* c is the function that defines the structure consttants  of the Lie algebra of dimension dim *)

aiReduceOneB[sigma_,p_, c_,dim_,popSize_:5, numGen_:1,dom_:Complexes,constraints_:{}][b_]:=
aiReduceOneB[sigma,p, c,dim,popSize, numGen,dom,constraints][b]= Module[{currentPop,weight},
currentPop =Map[Normal, Table[autoReduceB[c,dim,dom,constraints][b],{i,1,popSize}]];
weight =Map[fitnessMatrixList, Map[First, currentPop]];
Sort[buildManyGenerations[sigma,p,c,dim,weight,currentPop, numGen,dom,constraints][b], fitnessMatrixList[#1[[1]]] >= fitnessMatrixList[#2[[1]]]&][[1]]];

(* collect the constraints encountered during  compuputations *)

collectConditions[exp_]:=collectConditions[exp]= Module[{cond={},s},
s = exp/.ConditionalExpression[a_,b_]:>Last@{cond= Append[cond,b]; a};
    cond = DeleteDuplicates[cond];
{s, cond}];
unZip[lst_,lst1_:{},lst2_:{}]:= If[lst =={}, {lst1,lst2}, unZip[Rest[lst], Append[lst1, lst[[1]][[1]]], Append[lst2,lst[[1]][[2]]]]];

(* The main function -- The user need only this function. So, it must be documented *)

autoClassificationGen[sigma_,p_, c_,dim_,popSize_:5, numGen_:1,dom_:Complexes, cond_: False,constraints_:{}][b_,name_:\[Alpha]]:= Module[{s,perm,cd,f},
f =  Function[x, Not[Normal[Det[x]]=== 0]];
s= Map[aiReduceOneB[sigma,p,c,dim,popSize, numGen, dom,constraints],  simplifiedB[dim,c,b,dom,constraints]];  
perm = DeleteDuplicates[Map[#[[2]]&,s]];  (* Gather all the permutations of non-diagonal inner automorphisms used for each solution *)
s  = Join@@Map[  Join[#[[1]]]&,s]; (* Join the solutions *)
s = Map[collectConditions, s];               (* collect the constraints arising during computations *)
{s,cd} = unZip[s];(*s =Complement[ DeleteDuplicates[s], {DiagonalMatrix[ConstantArray[1,dim]]} ]; *) 
s = DeleteDuplicates[Join@@Map[renameVariable[name, Flatten[symbolicB[dim,b]],#, dom]&,s]]; (* rename the remaining parameters *)
cd = Fold[Or,False, Map[Simplify, DeleteDuplicates[Flatten[ Map[Fold[And ,True, #]&, cd]]]]]; (* conflate the constraints first with "And" then with "Or" *)
If[cond, {Select[s,f], cd, perm}, {Select[s,f], perm}]];  (* Ouput the result in the format { disjoint automorphism classes, constraints, permutations leading to each class } *)


autoClassificationBruteForceOneB[dim_,c_,dom_:Complexes,constraints_:{}][b_]:=autoClassificationBruteForceOneB[dim,c,dom,constraints][b]=
Module[{perms, reducts,best,s,cond},
 perms  = Permutations[Range[dim]];
reducts =Map[collectConditions,Map[ First,  Map [reduceB[c,dim, #,dom,constraints][b]&, perms]]];
best= {Sort[reducts, fitnessMatrixList[#1[[1]]]>=fitnessMatrixList[#2[[1]]]&][[1]]};
(*best = Select[reducts, fitnessMatrixList[#[[1]]]===fitnessMatrixList[best[[1]]]&];*)
s= Join@@Map[First, best]; 
cond =Fold[Or,False,DeleteDuplicates[Flatten[ Map [#[[2]]&,best]]]];
{s, cond}
]; 

autoClassificationBruteForce[dim_,c_,dom_: Complexes,constraints_:{}][b_,name_:\[Alpha]]:= Module[{s, cond, f},
f= Function[x, Not[Normal[Det[x]]===0]];
s = Map[autoClassificationBruteForceOneB[dim,c,dom,constraints], simplifiedB[dim,c,b,dom,constraints]];
cond = Fold[Or, DeleteDuplicates@Map[#[[2]]&,s]];
s = DeleteDuplicates[Join@@Map[renameVariable[name, Flatten[symbolicB[dim,b]],#,dom]&, Join@@Map[First, s] ]];
{Select[s, f] ,  cond}
];  
End[]
 Protect@@Names["cwsAutoClassRev`"]; 
EndPackage[]









